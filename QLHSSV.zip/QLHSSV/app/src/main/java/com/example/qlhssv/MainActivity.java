package com.example.qlhssv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.qlhssv.activity.ListClassesActivity;
import com.example.qlhssv.activity.ManageStudentsActivity;
import com.example.qlhssv.dialog.ClassDialog;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.btnNewClass).setOnClickListener(this);
        findViewById(R.id.btnListClass).setOnClickListener(this);
        findViewById(R.id.btnManageStudent).setOnClickListener(this);
        findViewById(R.id.btnLogOut).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnNewClass:
                ClassDialog dialog = new ClassDialog(this);
                dialog.show();
                break;
            case R.id.btnListClass:
                Intent intent = new Intent(this, ListClassesActivity.class);
                startActivity(intent);
                break;
            case R.id.btnManageStudent:
                Intent mngIntent = new Intent(this, ManageStudentsActivity.class);
                startActivity(mngIntent);
                break;
            case R.id.btnLogOut:
                break;
        }
    }
}