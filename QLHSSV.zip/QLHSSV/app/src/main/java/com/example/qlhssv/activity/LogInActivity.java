package com.example.qlhssv.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.qlhssv.R;

public class LogInActivity extends AppCompatActivity {
    EditText edUsername, edPassWord;
    Button btnLogIn, btnExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        edUsername = (EditText) findViewById(R.id.edUsername);
        edPassWord = (EditText) findViewById(R.id.edPassword);
        btnLogIn = (Button) findViewById(R.id.btnLogIn);
        btnExit = (Button) findViewById(R.id.btnExit);

        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}