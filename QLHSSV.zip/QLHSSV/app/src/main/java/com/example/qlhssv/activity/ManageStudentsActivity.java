package com.example.qlhssv.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.qlhssv.R;
import com.example.qlhssv.adapter.ClassesAdapter;
import com.example.qlhssv.adapter.StudentsAdapter;
import com.example.qlhssv.helper.DateTimeHelper;
import com.example.qlhssv.model.Classes;
import com.example.qlhssv.model.Student;
import com.example.qlhssv.sqlite.ClassesDao;
import com.example.qlhssv.sqlite.StudentDao;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class ManageStudentsActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText edStudentId, edName, edDob;
    private Spinner spClasses;
    private List<Classes> classesList;

    private List<Student> studentList;
    private ListView lvStudents;
    private StudentsAdapter studentsAdapter;
    private boolean isEdit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_students);
        edStudentId = findViewById(R.id.edStudentId);
        edName = findViewById(R.id.edName);
        edDob = findViewById(R.id.edDob);
        spClasses = findViewById(R.id.spClasses);

        lvStudents = findViewById(R.id.lvStudent);
        lvStudents.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Student std = studentList.get(i);
                edStudentId.setText(std.getId());
                edName.setText(std.getName());
                edDob.setText(DateTimeHelper.toString(std.getDob()));
                isEdit = true;
            }
        });
        fillClassesToSpinner();
        findViewById(R.id.btnSave).setOnClickListener(this);
        findViewById(R.id.btnDelete).setOnClickListener(this);

    }
    private  void fillClassesToSpinner(){
        ClassesDao dao =new ClassesDao(this);
        classesList = dao.getAll();
        ClassesAdapter classesAdapter = new ClassesAdapter(this, classesList);
        spClasses.setAdapter(classesAdapter);
    }
    private void  fillStudentsToListView(){
        StudentDao dao = new StudentDao(this);
        try {
            Classes cls = (Classes) spClasses.getSelectedItem();
            studentList = dao.getAllByClass(cls.getId());

            studentsAdapter = new StudentsAdapter(this, studentList);
            lvStudents.setAdapter(studentsAdapter);

            spClasses.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    fillStudentsToListView();
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });
        }catch (Exception ex){
            ex.printStackTrace();
            Toast.makeText(this, "ERROR: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View view) {
        StudentDao dao = new StudentDao(this);
        switch (view.getId()){
            case R.id.btnSave:
                try {
                    Student std = new Student();
                    std.setId(edStudentId.getText().toString());
                    std.setName(edName.getText().toString());
                    std.setDob(DateTimeHelper.toDate(edDob.getText().toString()));

                    Classes cls = (Classes) spClasses.getSelectedItem();
                    std.setClassId(cls.getId());
                    String msg;
                    if (!isEdit) {
                        dao.insert(std);
                        msg = "Sinh Vien Da Duoc Luu!";
                    }else {
                        dao.update(std);
                        msg = "Sinh viên đã được cập nhật!";
                    }
                    Snackbar snackbar = Snackbar.make(view,msg, Snackbar.LENGTH_LONG);
                    snackbar.show();
                    clearInputFields();

                    isEdit = false;
                    fillStudentsToListView();

                }catch (Exception ex){
                    ex.printStackTrace();
                    Toast.makeText(this, "ERROR" + ex.getMessage(), Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.btnDelete:
                if (isEdit && !edStudentId.getText().toString().equals("")){
                    String id = edStudentId.getText().toString();
                    dao.delete(id);

                    fillStudentsToListView();
                    Snackbar.make(view, "Sinh Viên Đã Được Xóa!", Snackbar.LENGTH_LONG).show();
                    clearInputFields();
                }
                break;
        }
    }

    private void clearInputFields() {
        edStudentId.setText("");
        edName.setText("");
        edDob.setText("");
    }
}