package com.example.qlhssv.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.qlhssv.R;
import com.example.qlhssv.model.Classes;
import com.example.qlhssv.sqlite.ClassesDao;

public class ClassDialog extends Dialog implements View.OnClickListener {
    private Context context;
    private EditText edClassId, edName;

    public ClassDialog(@NonNull Context context) {
        super(context);
        this.context = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.class_dialog);

        edClassId = findViewById(R.id.edClassId);
        edName = findViewById(R.id.edName);

        findViewById(R.id.btnSave).setOnClickListener(this);
        findViewById(R.id.btnClose).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnSave:
                Classes cls = new Classes();
                cls.setName(edName.getText().toString());
                ClassesDao dao = new ClassesDao(context);
                dao.insert(cls);
                Toast.makeText(context, "Lớp Đã Được Lưu Thành Công", Toast.LENGTH_SHORT).show();
                dismiss();
                break;
                case R.id.btnClose:
                    dismiss();
                    break;
        }
    }
}
